<head>
    <style>
        body {
            margin: 0px;
            background: url("bg.png");
        }

        .my-table {
            display: grid;
            grid-template-columns: 80% auto;
            background-color: #2196F3;
            padding: 10px;
            margin: 10px;
        }

        .my-table .son {
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.8);
            padding: 20px;
            font-size: 30px;
            text-align: center;
            /* width: 20px;
            height: 20px; */
        }

        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
            background-color: white;
        }

        th {
            font-size: 30px;
        }

        td {
            font-size: 20px;
            font-family: cursive;
        }

        td,
        th {
            border: 4px solid;
            border-color: blue;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #58a4f6;
        }


        .title {
            height: 80px;
            width: 80%;
            background: #0f33d2;
            border-radius: 50px 5px 0 0;
            color: #fff;
            font-size: 40px;
            font-weight: 600;
            margin: 20px auto 5px;
            display: flex;
            align-items: center;
            justify-content: center;

        }

        .back {
            display: block;
            text-align: center;
            padding: 10px;
            background-color: #c0c0c0e3;
            border-radius: 40px 0 0 0;
            color: #0056b3;
            font-weight: bold;
            width: 30%;
            font-size: 38px;
            margin: 3px auto;
            text-decoration: none;
            border-top: 2px solid #ddd;
        }

        .back:hover {
            color: white;
            font-size: 50px;
            background-color: #0056b3;
        }

        .view {

            background-color: #0056b3;
            color: white;
            border: none;
            padding: 6px;
            font-size: 24px;
            display: block;
            width: 60px;
            text-decoration: none;
            font-weight: bold;
            /* border-radius: 8px; */
            cursor: pointer;
            transition: transform 0.2s, background-color 0.3s ease;
        }

        .patient {
            text-transform: capitalize;
            color: white;
        }

        .sorry {
            display: grid;
            margin: 100px auto 16px;
            height: 200px;
            /* grid-template-columns: auto auto auto; */
            background-color: #2196F3;
            padding: 10px;
        }

        .sorry-son {
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.8);
            padding: 77px;
            font-size: 30px;
            text-align: center;
        }
    </style>
</head>
<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];

    $stmt = $conn->prepare("SELECT * FROM patients WHERE name = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
?>

        <div class="container">
            <div class="title"><span class="patient"><?php echo " {$row['name']}" ?></span></div>
            <div class="my-table">
                <div class="son">
                    <table>
                        <tr>
                            <td>ID</td>
                            <td><?php echo "{$row['id']}" ?></td>

                        </tr>
                        <tr>
                            <td>Name</td>
                            <td><?php echo "{$row['name']}" ?></td>
                        </tr>
                        <tr>
                            <td>Phone</td>
                            <td><?php echo "{$row['phone']}" ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><?php echo "{$row['email']}" ?></td>
                        </tr>
                        <tr>
                            <td>Gender</td>
                            <td><?php echo "{$row['gender']}" ?></td>
                        </tr>
                        <tr>
                            <td>Age</td>
                            <td><?php echo "{$row['age']}" ?></td>
                        </tr>
                        <tr>
                            <td>Address</td>
                            <td><?php echo "{$row['address']}" ?></td>

                        </tr>
                        <tr>
                            <td>Notes</td>
                            <td><?php echo "{$row['notes']}" ?></td>

                        </tr>
                        <tr>
                            <td>Files</td>
                            <!-- <td><a class="view" href="p-files.php">View</a></td> -->
                            <td><a class="files view" href="add_file.php?id=<?php echo $row['id'] ?>">Files</a></td>
                        </tr>
                    </table>
                </div>
                <div class="son"><img src="patient_photos/<?= htmlspecialchars($row['photo']) ?>" width="150" height="150" alt=""></div>
                <!-- <a href="manage.html" class="back">Back</a> -->
            </div>
            <a href="manage.html" class="back">Back</a>
        </div>
        <?php

        ?>
    <?php
    } else {
        // echo "No patient found with that name.";
    ?>
        <div class="sorry">
            <div class="sorry-son">Sorry No Patient Found </div>

        </div>
        <a href="search.html" class="back">Back</a>
<?php
    }
}
?>