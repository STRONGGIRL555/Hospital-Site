<?php
$conn = new mysqli("localhost", "root", "", "hospital_db.sql", 566);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
