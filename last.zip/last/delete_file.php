
<?php
include 'db.php';
echo $_GET['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $file_id = $_POST['file_id'];
    $patient_id = $_POST['patient_id'];

    // Get file name to delete it from disk
    $stmt = $conn->prepare("SELECT file_name FROM patient_files WHERE id = ?");
    $stmt->bind_param("i", $file_id);
    $stmt->execute();
    $stmt->bind_result($file_name);
    $stmt->fetch();
    $stmt->close();

    if ($file_name && file_exists("uploads/$file_name")) {
        unlink("uploads/$file_name");
    }

    // Delete from DB
    $stmt = $conn->prepare("DELETE FROM patient_files WHERE id = ?");
    $stmt->bind_param("i", $file_id);
    $stmt->execute();

    header("Location: files.php?id=$patient_id");
    exit;
}
