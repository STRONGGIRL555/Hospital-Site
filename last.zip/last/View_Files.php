<h1>welcome</h1>
<?php
include 'db.php';
$patient_id = $_GET['id'];
echo $patient_id;

$sql = "SELECT * FROM patient_files WHERE patient_id = $patient_id ORDER BY FIELD(file_type, 'examination', 'labs', 'rays', 'other')";
$result = $conn->query($sql);

echo "<h2>ملفات المريض</h2>";
echo "<ul>";
while ($row = $result->fetch_assoc()) {
    echo "<li><strong>" . $row['file_type'] . ":</strong> " . $row['file_name'] . " - <em>" . $row['uploaded_at'] . "</em></li>";
}
echo "</ul>";

echo "<a href='view_patients.php'>رجوع</a>";
?>


?>