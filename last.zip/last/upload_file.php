<head>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            background-color: #39393996;
            background-image: url('bg.png');
            padding: 0;
        }

        .back {
            display: block;
            text-align: center;
            padding: 10px;
            background-color: #c0c0c0e3;
            border-radius: 40px 0 0 0;
            color: #0056b3;
            font-weight: bold;
            width: 30%;
            font-size: 38px;
            margin: 3px auto;
            text-decoration: none;
            border-top: 2px solid #ddd;
        }

        .back:hover {
            color: white;
            font-size: 50px;
            background-color: #0056b3;
        }

        .updated {
            display: grid;
            margin: 100px auto 16px;
            height: 200px;
            /* grid-template-columns: auto auto auto; */
            background-color: green;
            padding: 10px;
        }

        .updated-son {
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.8);
            padding: 77px;
            text-transform: capitalize;
            font-size: 30px;
            text-align: center;
        }
    </style>
</head>

<?php
include 'db.php'; // الاتصال بقاعدة البيانات باستخدام mysqli

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // تأكد أن البيانات وصلت
    if (isset($_POST['patient_id']) && isset($_POST['file_type']) && isset($_FILES['file'])) {
        $patient_id = $_POST['patient_id'];
        $file_type = $_POST['file_type'];

        $upload_dir = 'uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true); // إنشاء مجلد لو مش موجود
        }

        $file_name = basename($_FILES['file']['name']);
        $target = $upload_dir . $file_name;

        // رفع الملف
        if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
            // إدخال البيانات في قاعدة البيانات
            $stmt = $conn->prepare("INSERT INTO patient_files (patient_id, file_name, file_type) VALUES (?, ?, ?)");
            if ($stmt) {
                $stmt->bind_param("iss", $patient_id, $file_name, $file_type);
                if ($stmt->execute()) {
                    // echo "File uploaded and saved successfully.";
?>
                    <div class="updated">
                        <div class="updated-son">File uploaded and saved successfully. </div>

                    </div>
                    <a href="add_file.php" class="back">Back</a>
<?php
                } else {
                    echo "Database insert failed: " . $stmt->error;
                }
                $stmt->close();
            } else {
                echo "Prepare failed: " . $conn->error;
            }
        } else {
            echo "Upload failed. Please check file permissions.";
        }
    } else {
        echo "Missing form data.";
    }
} else {
    echo "Invalid request.";
}
?>