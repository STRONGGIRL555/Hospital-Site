<head>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            background-color: #39393996;
            background-image: url('bg.png');
            padding: 0;
        }

        .back {
            display: block;
            text-align: center;
            padding: 10px;
            background-color: #c0c0c0e3;
            border-radius: 40px 0 0 0;
            color: #0056b3;
            font-weight: bold;
            width: 30%;
            font-size: 38px;
            margin: 3px auto;
            text-decoration: none;
            border-top: 2px solid #ddd;
        }

        .back:hover {
            color: white;
            font-size: 50px;
            background-color: #0056b3;
        }

        .added {
            display: grid;
            margin: 100px auto 16px;
            height: 200px;
            /* grid-template-columns: auto auto auto; */
            background-color: green;
            padding: 10px;
        }

        .added-son {
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.8);
            padding: 77px;
            text-transform: capitalize;
            font-size: 30px;
            text-align: center;
        }
    </style>
</head>
<?php
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    // $photo_name = 'def.png';
    $address = $_POST['address'];
    $notes = $_POST['notes'];
    // *********************
    $photo_name = 'def.png'; // الافتراضية
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $upload_dir = 'patient_photos/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $original_name = basename($_FILES['photo']['name']);
        $photo_name = time() . "_" . $original_name;
        $target = $upload_dir . $photo_name;

        if (move_uploaded_file($_FILES['photo']['tmp_name'], $target)) {
            // تم الرفع بنجاح
        } else {
            $photo_name = 'def.png'; // فشل الرفع
        }
    }
    $stmt = $conn->prepare("INSERT INTO patients (name, age, gender, phone, email, address, notes,photo) VALUES (?, ?, ?, ?, ?, ?,? ,?)");
    $stmt->bind_param("sissssss", $name, $age, $gender, $phone, $email, $address, $notes, $photo_name);
    $stmt->execute();
?>

    <!-- <h2>Patient added</h2><a href='manage.html'>Back</a> -->
    <div class="added">
        <div class="added-son">patient <?php ?> added sucessfully </div>

    </div>
    <a href="manage.html" class="back">Back</a>
<?php
}

?>