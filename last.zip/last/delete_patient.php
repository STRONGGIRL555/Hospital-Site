<head>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            background-color: #39393996;
            background-image: url('bg.png');
            padding: 0;
        }

        .back {
            display: block;
            text-align: center;
            padding: 10px;
            background-color: #c0c0c0e3;
            border-radius: 40px 0 0 0;
            color: #0056b3;
            font-weight: bold;
            width: 30%;
            font-size: 38px;
            margin: 3px auto;
            text-decoration: none;
            border-top: 2px solid #ddd;
        }

        .back:hover {
            color: white;
            font-size: 50px;
            background-color: #0056b3;
        }

        .deleted {
            display: grid;
            margin: 100px auto 16px;
            height: 200px;
            /* grid-template-columns: auto auto auto; */
            background-color: red;
            padding: 10px;
        }

        .deleted-son {
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.8);
            padding: 77px;
            text-transform: capitalize;
            font-size: 30px;
            text-align: center;
        }
    </style>
</head>

<?php
include 'db.php';
$id = $_POST['id'];
$stmt = $conn->prepare("DELETE FROM patients WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
?>

<div class="deleted">
    <div class="deleted-son">patient <?php ?> deleted sucessfully </div>

</div>
<a href="manage.html" class="back">Back</a>