-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:566
-- Generation Time: Jun 23, 2025 at 09:52 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_db.sql`
--

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `age`, `gender`, `phone`, `email`, `address`, `notes`, `created_at`, `photo`) VALUES
(41, 'shimaa', 22, 'female', '01128351902', 'shimaa1234@gmail.com', 'luxor', 'Note1', '2025-06-10 22:24:10', '1749594250_g1.jpeg'),
(42, 'hoda', 33, 'female', '01222672379', 'Hoda1234@gmail.com', 'luxor', '', '2025-06-10 22:24:44', 'def.png'),
(43, 'ali', 44, 'male', '01264893587', 'ali_7564@gmail.com', 'Aswan', 'this patient', '2025-06-10 22:26:03', '1749594363_avatar-06.png');

-- --------------------------------------------------------

--
-- Table structure for table `patient_files`
--

CREATE TABLE `patient_files` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `file_type` enum('examination','labs','rays','other') NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_files`
--

INSERT INTO `patient_files` (`id`, `patient_id`, `file_type`, `file_name`, `uploaded_at`) VALUES
(46, 41, 'labs', 'lab1.jpeg', '2025-06-11 01:26:26'),
(47, 41, 'examination', 'test.xlsx', '2025-06-11 01:26:45'),
(48, 41, 'rays', 'ray1.jpeg', '2025-06-11 01:27:04'),
(49, 42, 'examination', 'Internet of Things.docx', '2025-06-11 01:27:16'),
(50, 41, 'other', 'User Equipment.docx', '2025-06-11 01:27:32'),
(51, 43, 'rays', 'images (8).jpeg', '2025-06-11 01:28:00'),
(52, 43, 'examination', 'images (9).jpeg', '2025-06-11 01:28:12'),
(53, 43, 'examination', 'test.xlsx', '2025-06-11 01:28:28'),
(54, 42, 'examination', 'port security.pdf', '2025-06-11 01:28:57'),
(55, 42, 'rays', 'ray3.jpeg', '2025-06-11 01:29:39'),
(56, 43, 'labs', 'User Equipment.pdf', '2025-06-11 01:30:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_files`
--
ALTER TABLE `patient_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `patient_files`
--
ALTER TABLE `patient_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `patient_files`
--
ALTER TABLE `patient_files`
  ADD CONSTRAINT `patient_files_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
