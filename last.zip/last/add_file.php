<?php

include 'db.php';
// echo $_GET['id'];
?>

<head>
    <style>
        body {
            background-image: url("pattern.png");
            background-color: gray;
        }

        .back {
            display: block;
            text-align: center;
            padding: 10px;
            background-color: #c0c0c0e3;
            border-radius: 40px 0 0 0;
            color: #0056b3;
            font-weight: bold;
            width: 30%;
            font-size: 38px;
            margin: 3px auto;
            text-decoration: none;
            border-top: 2px solid #ddd;
        }

        .back:hover {
            color: white;
            font-size: 50px;
            background-color: #0056b3;
        }

        .container {

            margin: 200px auto 20px;
            height: 278px;
            /* align-items: center; */
            display: grid;
            grid-template-columns: auto auto;
            background-color: #2196F3;
            padding: 10px;
        }



        .grid-item {
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.8);
            padding: 20px;
            font-size: 24px;
            /* text-align: center; */
        }

        .display {
            align-items: center;
        }

        .up {
            margin: 0px;
        }

        .btn-up,
        .display-link {
            margin: 10px;
            display: block;
            padding: 10px;
            border: 3px solid black;
            font-size: 18px;
            width: fit-content;
            background-color: #1d60dc;
            cursor: pointer;
            color: white;
            text-decoration: none;
        }

        .btn-up {
            font-size: 18px;
        }

        .display-link {
            font-size: 30px;
        }

        .display-link:hover {
            background-color: white;
            /* cursor: pointer; */
            color: blue;
        }

        .sel {

            height: 42px;
            background-color: rgba(255, 255, 255, 0.8);
            font-size: 17px;
            text-transform: capitalize;
            display: inline-block;
            width: fit-content;
        }

        .op:hover {
            background-color: #1d60dc;
        }

        .file {
            display: inline-block;
            height: 33px;
        }
    </style>
</head>
<div class="container">

    <div class="form grid-item">
        <form class="up" action="upload_file.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="patient_id" value="<?= $_GET['id'] ?>">

            <label>Select File : </label>
            <input class="file" type="file" name="file" required>
            <!-- 'examination','labs','rays','other' -->
            <br>
            <label>Type :</label>
            <select name="file_type" required class="sel">
                <option class="op" value="rays">rays</option>
                <option class="op" value="examination">examination</option>
                <option class="op" value="labs">labs</option>
                <option class="op" value="other">other</option>
            </select><br>

            <button class="btn-up" type="submit">Upload</button>
        </form>
    </div>
    <div class="display grid-item"><a class="display-link" href="files.php?id=<?= $_GET['id'] ?>">display All Files</a></div>

</div>


<a href="view_patients.php" class="back">Back</a>