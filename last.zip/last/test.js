
const title = document.getElementById('Hospital-title');
let text = "CareHealth Hospital".split('');
let index = 0;

function typeEffect() {
  if (index < text.length) {
    title.textContent += text[index];
    index++;
    setTimeout(typeEffect, 150);
  }
}


window.onload = function () {
  title.textContent = '';
  typeEffect();
};

