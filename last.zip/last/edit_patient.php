<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            background-color: #39393996;
            background-image: url('bg.png');
            padding: 0;
        }

        .container {
            max-width: 700px;
            margin: 22px auto;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            overflow: hidden;
        }

        .header {
            background-color: #0056b3;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .header h2 {
            margin: 0;
        }

        .form-container {
            padding: 20px 20px 2px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-group textarea {
            resize: none;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #0056b3;
            box-shadow: 0 0 5px rgba(0, 86, 179, 0.5);
        }

        .form-buttons {
            text-align: center;
            margin-top: 20px;
        }

        .form-buttons .files {
            padding: 11px 30px;
        }

        .form-buttons button {
            padding: 10px 20px;
        }

        .form-buttons button,
        .files {
            background-color: #003d80;
            color: white;
            border: none;
            /* padding: 10px 20px; */
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s;
        }

        .form-buttons button,
        .files:hover {
            background-color: #003d80;
            transform: scale(1.05);
        }

        .form-buttons .cancel {
            background-color: #ccc;
            color: #333;
        }

        .form-buttons .cancel:hover {
            background-color: #bbb;
        }

        .back {
            display: block;
            text-align: center;
            padding: 10px;
            background-color: #c0c0c0e3;
            border-radius: 40px 0 0 0;
            color: #0056b3;
            font-weight: bold;
            width: 30%;
            font-size: 38px;
            margin: 3px auto;
            text-decoration: none;
            border-top: 2px solid #ddd;
        }

        .back:hover {
            color: white;
            font-size: 50px;
            background-color: #0056b3;
        }

        .sorry {
            display: grid;
            margin: 100px auto 16px;
            height: 200px;
            /* grid-template-columns: auto auto auto; */
            background-color: #2196F3;
            padding: 10px;
        }

        .sorry-son {
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.8);
            padding: 77px;
            font-size: 30px;
            text-align: center;
        }
    </style>
</head>
<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];

    $stmt = $conn->prepare("SELECT * FROM patients WHERE name = ?");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
?>

        <body>
            <div class="container">
                <div class="header">
                    <h2>Edit : <?php echo $_POST['name'] ?> Data</h2>
                </div>
                <div class="form-container">
                    <form method="POST" action="update.php">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">

                        <div class="form-group">
                            <label for="name">Patient Name:</label>
                            <input type="text" id="name" name="name" value="<?= $row['name'] ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="age">Age:</label>
                            <input type="number" id="age" name="age" value="<?= $row['age'] ?>" required>
                        </div>
                        <!-- Age: <input type="text" name="age" ><br> -->
                        <div class="form-group">
                            <label for="gender">Gender:</label>
                            <select id="gender" name="gender" required>
                                <option value="" disabled selected>Select gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <!-- Gender: <input type="text" name="gender" value="
                        // $row['gender']
                        
                         "><br> -->
                        <div class="form-group">
                            <label for="phone">Phone Number:</label>
                            <input type="tel" id="phone" name="phone" value="<?= $row['phone'] ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="address">Address:</label>
                            <input type="text" id="address" name="address" value="<?= $row['address'] ?>"></input>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address:</label>
                            <input type="email" id="email" name="email" value="<?= $row['email'] ?>">
                        </div>
                        <div class="form-group">
                            <label for="notes">Additional Notes:</label>
                            <textarea id="notes" name="notes" rows="2" value="<?= $row['notes'] ?>"></textarea>
                        </div>
                        <!-- <input type="submit" value="Update"> -->
                        <div class="form-buttons">
                            <a class="files" href="add_file.php?id=<?php echo $row['id'] ?>">Files</a>
                            <button type="submit">Update</button>
                            <!-- <button type="button" class="cancel" onclick="window.history.back()">Cancel</button> -->
                        </div>
                    </form>
                </div>
            </div>
        </body>
    <?php
    } else {
        // echo "No patient found with that name.";
    ?>
        <div class="sorry">
            <div class="sorry-son">Sorry ,No patient found with that name. </div>

        </div>
        <a href="edit.html" class="back">Back</a>
<?php
    }
}
?>