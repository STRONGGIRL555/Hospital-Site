<?php
include 'db.php';

$id = $_POST['id'];
$name = $_POST['name'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$address = $_POST['address'];
$notes = $_POST['notes'];

$stmt = $conn->prepare("UPDATE patients SET name=?, age=?, gender=?, phone=?, email=?, address=?, notes=? WHERE id=?");
$stmt->bind_param("sisssssi", $name, $age, $gender, $phone, $email, $address, $notes, $id);
$stmt->execute();

// echo "<h2>Patient updated.</h2><a href='manage.html'>Back</a>";
?>

<head>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            background-color: #39393996;
            background-image: url('bg.png');
            padding: 0;
        }

        .back {
            display: block;
            text-align: center;
            padding: 10px;
            background-color: #c0c0c0e3;
            border-radius: 40px 0 0 0;
            color: #0056b3;
            font-weight: bold;
            width: 30%;
            font-size: 38px;
            margin: 3px auto;
            text-decoration: none;
            border-top: 2px solid #ddd;
        }

        .back:hover {
            color: white;
            font-size: 50px;
            background-color: #0056b3;
        }

        .updated {
            display: grid;
            margin: 100px auto 16px;
            height: 200px;
            /* grid-template-columns: auto auto auto; */
            background-color: green;
            padding: 10px;
        }

        .updated-son {
            background-color: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.8);
            padding: 77px;
            text-transform: capitalize;
            font-size: 30px;
            text-align: center;
        }
    </style>
</head>
<div class="updated">
    <div class="updated-son">patient <?php ?> Updated sucessfully </div>

</div>
<a href="manage.html" class="back">Back</a>