<?php
include 'db.php';
$patient_id = $_GET['id'] ?? 0;
$type_filter = $_GET['type'] ?? 'all';

$types = [
    'rays' => 'rays',
    'examination' => 'examination',
    'labs' => 'labs',
    'other' => 'other'
];

// Prepare the query
if ($type_filter === 'all') {
    $stmt = $conn->prepare("SELECT * FROM patient_files WHERE patient_id = ?");
    $stmt->bind_param("i", $patient_id);
} else {
    $stmt = $conn->prepare("SELECT * FROM patient_files WHERE patient_id = ? AND file_type = ?");
    $stmt->bind_param("is", $patient_id, $type_filter);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Patient Files</title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            margin: 20px;
            background-color: #4f4f4f40;
            background-image: url('pattern.png');
        }

        .navbar {
            background-color: #0056b3;
            margin: 10px 2px;
            padding: 10px 0px;
            /* height: 60px; */
        }

        .navbar a,
        .btn-dlt {
            /* margin-right: 15px; */
            padding: 10px 15px;

            text-decoration: none;
            font-size: 22px;
            color: white;
            cursor: pointer;
            font-family: 'Times New Roman', Times, serif;
            margin-bottom: 10px;
            /* /* border-radius: 5px; */
        }

        .btn-dlt {
            background-color: #f43232;
            border: none;
        }


        .navbar a.active {
            background-color: #ccc;
            color: black;
        }

        .file-card {
            display: inline-block;
            width: 200px;
            margin: 10px;
            border: 4px solid #0056b3;
            /* border-radius: 16px; */
            padding: 10px;
            /* background-color: #00d8ff8a; */
            background-color: white;
            text-align: center;
        }

        .file-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }

        .file-card form {
            margin-top: 10px;
        }

        .title {
            height: 80px;
            width: 80%;
            background: #0f33d2;
            border-radius: 50px 5px 0 0;
            color: #fff;
            font-size: 40px;
            margin-bottom: 10px;
            font-weight: 600;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .back {
            display: block;
            text-align: center;
            padding: 10px;
            background-color: #c0c0c0e3;
            border-radius: 40px 0 0 0;
            color: #0056b3;
            font-weight: bold;
            width: 30%;
            font-size: 38px;
            margin: 3px auto;
            text-decoration: none;
            border-top: 2px solid #ddd;
        }

        .back:hover {
            color: white;
            font-size: 50px;
            background-color: #0056b3;
        }
    </style>
</head>

<body>

    <div class="title">patient Files</div>

    <div class="navbar">
        <a href="?id=<?= $patient_id ?>&type=all" class="<?= $type_filter === 'all' ? 'active' : '' ?>">All</a>
        <?php foreach ($types as $key => $label): ?>
            <a href="?id=<?= $patient_id ?>&type=<?= $key ?>" class="<?= $type_filter === $key ? 'active' : '' ?>">
                <?= $label ?>
            </a>
        <?php endforeach; ?>
    </div>

    <div>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="file-card">
                <!-- <img src="uploads/
                //  htmlspecialchars($row['file_name']) 
                 ?>" alt="File"> -->
                <?php
                $file_name = htmlspecialchars($row['file_name']);
                $ext = pathinfo($file_name, PATHINFO_EXTENSION);

                switch (strtolower($ext)) {
                    case 'pdf':
                        $icon = 'icons/pdf.jpeg';
                        break;
                    case 'doc':
                    case 'docx':
                        $icon = 'icons/word.jpeg';
                        break;
                    case 'xls':
                    case 'xlsx':
                        $icon = 'icons/excel.png';
                        break;
                    case 'jpg':
                    case 'jpeg':
                    case 'png':
                    case 'gif':
                        $icon = "uploads/$file_name";
                        break;
                    default:
                        $icon = 'icons/file.png';
                        break;
                }
                ?>
                <img src="<?= $icon ?>" alt="File">

                <form method="POST" action="delete_file.php" onsubmit="return confirm('Delete this file?');">
                    <input type="hidden" name="file_id" value="<?= $row['id'] ?>">
                    <input type="hidden" name="patient_id" value="<?= $patient_id ?>">
                    <button class="btn-dlt" type="submit">Delete</button>
                </form>
                <!-- be carful -->
                <form method="GET" action="read_file.php" target="_blank">
                    <input type="hidden" name="file" value="<?= htmlspecialchars($row['file_name']) ?>">

                    <button class="btn-dlt" type="submit">dis/edit</button>
                </form>
            </div>
        <?php endwhile; ?>
    </div>
    <a href="view_patients.php" class="back">Back</a>
</body>

</html>