<?php
include "db.php";
$file = $_GET['file'] ?? '';

$filepath = "uploads/" . basename($file);

if (!file_exists($filepath)) {
    echo "File not found.";
    exit;
}

// أنواع الملفات النصية التي يمكن تعديلها:
$text_extensions = ['txt', 'html', 'php', 'csv', 'log'];

$ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));

if (in_array($ext, $text_extensions)) {
    $content = file_get_contents($filepath);
?>
    <h2>Edit File: <?= htmlspecialchars($file) ?></h2>
    <form method="POST" action="save_file.php">
        <input type="hidden" name="file" value="<?= htmlspecialchars($file) ?>">
        <textarea name="content" rows="20" cols="100"><?= htmlspecialchars($content) ?></textarea><br>
        <button type="submit">Save Changes</button>
    </form>
<?php
} else {
    // عرض الملف مباشرة (مثل PDF أو صورة)
    echo "<h2>View File: " . htmlspecialchars($file) . "</h2>";
    echo "<iframe src='$filepath' width='100%' height='100%'></iframe>";
}
?>