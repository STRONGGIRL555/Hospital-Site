<!DOCTYPE html>
<html>

<head>
  <style>
    body {
      margin: 0px;
      background: url("bg.png");
    }

    table {
      font-family: arial, sans-serif;
      border-collapse: collapse;
      width: 100%;
      margin-top: 20px;
      background-color: white;
    }

    th {
      font-size: 30px;
    }

    td {
      font-size: 20px;
      font-family: cursive;
    }

    td,
    th {
      border: 4px solid;
      border-color: blue;
      text-align: left;
      padding: 8px;
    }

    tr:nth-child(even) {
      background-color: #58a4f6;
    }


    .title {
      height: 80px;
      width: 80%;
      background: #0f33d2;
      border-radius: 50px 5px 0 0;
      color: #fff;
      font-size: 40px;
      font-weight: 600;
      margin: auto;
      display: flex;
      align-items: center;
      justify-content: center;

    }

    .back {
      display: block;
      text-align: center;
      padding: 10px;
      background-color: #c0c0c0e3;
      border-radius: 40px 0 0 0;
      color: #0056b3;
      font-weight: bold;
      width: 30%;
      font-size: 38px;
      margin: 3px auto;
      text-decoration: none;
      border-top: 2px solid #ddd;
    }

    .back:hover {
      color: white;
      font-size: 50px;
      background-color: #0056b3;
    }

    .view {

      background-color: #0056b3;
      color: white;
      border: none;
      padding: 6px;
      font-size: 24px;
      display: block;
      width: 84%;
      text-decoration: none;
      font-weight: bold;
      /* border-radius: 8px; */
      cursor: pointer;
      transition: transform 0.2s, background-color 0.3s ease;
    }
  </style>
</head>
<?php
include 'db.php';

?>

<body>
  <div class="container">
    <!-- <div class="main"> -->
    <div class="title">All Patients</div>
    <!-- </div> -->
    <div class="my-table">
      <table>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Phone</th>
          <th>Email</th>
          <th>Gender</th>
          <th>Age</th>
          <th>Address</th>
          <th>Notes</th>
          <th>Files</th>
        </tr>
        <?php
        include 'db.php';
        $result = $conn->query("SELECT * FROM patients");
        echo "<div class='container'>";
        while ($row = $result->fetch_assoc()) { ?>
          <tr>
            <td><?php echo "{$row['id']}" ?></td>
            <td><?php echo "{$row['name']}" ?></td>
            <td><?php echo "{$row['phone']}" ?></td>
            <td><?php echo "{$row['email']}" ?></td>
            <td><?php echo "{$row['gender']}" ?></td>
            <td><?php echo "{$row['age']}" ?></td>
            <td><?php echo "{$row['address']}" ?></td>
            <td><?php echo "{$row['notes']}" ?></td>
            <!-- <td><a class="view" href="View_Files.php?id=<?php echo "{$row['id']}" ?>">View</a></td> -->
            <td><a class="files view" href="add_file.php?id=<?php echo $row['id'] ?>">Files</a></td>
          </tr>
        <?php
          // echo "<p>ID: {$row['id']} - Name: {$row['name']} - Phone: {$row['phone']}</p><hr>";
        }
        echo "</div>";
        ?>

      </table>
      <!-- <a href='manage.html'>Back</a> -->
      <a href="manage.html" class="back">Back</a>

    </div>
  </div>

</body>

<!-- Mirrored from www.w3schools.com/html/tryit.asp?filename=tryhtml_table_intro by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 09 Sep 2024 11:42:29 GMT -->

</html>