<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['name'];
  $stmt = $conn->prepare("SELECT * FROM patients WHERE name = ?");
  $stmt->bind_param("s", $name);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($row = $result->fetch_assoc()) {
?>
    <form method="POST" action="edit_patient.php">
      <input type="hidden" name="id" value="<?= $row['id'] ?>">
      Name: <input type="text" name="name" value="<?= $row['name'] ?>"><br>
      Age: <input type="text" name="age" value="<?= $row['age'] ?>"><br>
      Gender: <input type="text" name="gender" value="<?= $row['gender'] ?>"><br>
      Phone: <input type="text" name="phone" value="<?= $row['phone'] ?>"><br>
      Email: <input type="text" name="email" value="<?= $row['email'] ?>"><br>
      Address: <input type="text" name="address" value="<?= $row['address'] ?>"><br>
      Notes: <input type="text" name="notes" value="<?= $row['notes'] ?>"><br>
      <input type="submit" value="Update">
    </form>
<?php
  } else {
    echo "No patient found with that name.";
  }
}
?>